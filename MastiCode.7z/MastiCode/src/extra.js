// if (char === "[" || char === "]") {
//     tokens.push({ type: "bracket", value: char });
//     current++;
//     continue;
//   }

// tokens
// [keyword:rakho]
// [variable:a]
// [operator: = ]
// [number:10]
// [terminator: ;]
// rakho a = '12';

// const myCode = `chalo shuru kren {
//       rakho a = '12'
//       dikhao(a);
//     dohraoJabTak (rakho i = 0; i < umarList.length; i = i + 1) {
//         rakho currentAge = umarList[i];

//         agar (currentAge < 18) {
//             dikhao("Age " + currentAge + ": You are a minor.");
//         } wrna agar (currentAge >= 18 && currentAge <= 60) {
//             dikhao("Age " + currentAge + ": You are an adult.");
//         } wrna {
//             dikhao("Age " + currentAge + ": You are a senior citizen.");
//         }
//     }
//     Bas Khatam
//   }`;
